# Scratch Space

This directory is intended for development and testing artifacts.
Feel free to create temporary files or subdirectories here.
All contents are ignored by Git except for this README, so nothing
placed in `scratch_space/` will be committed by default.
