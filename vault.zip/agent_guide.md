# 🧠 Agentic Prompting Framework for Knowledge Graph Development

## 1. Environment Setup and Context

### Current Environment
- Python 3.11.8
- RDFLib for graph management
- Pytest with pytest-asyncio for testing
- Loguru for logging
- Project Structure:
  ```
  semant/
  ├── kg/
  │   ├── models/
  │   │   ├── graph_manager.py
  │   │   └── graph_initializer.py
  │   └── schemas/
  │       ├── core.ttl
  │       └── sample_data.ttl
  ├── tests/
  │   └── test_knowledge_graph.py
  └── scratch_space/
      └── wp1_progress.md
  ```

### Key Components
- KnowledgeGraphManager: Core graph operations
- GraphInitializer: Ontology and data loading
- Test Suite: Comprehensive coverage of graph operations

## 2. Working Style Pattern

### Progress Updates Format
```markdown
## Update: [Title] ([Date])

### [Category 1]
- Point 1
- Point 2
- Point 3

### [Category 2]
- Analysis point 1
- Analysis point 2

### Feedback for User
- Key observation 1
- Key observation 2
- Recommendation

### Next Steps
1. Action item 1
2. Action item 2
3. Action item 3
```

### Categories Used
- Test Results
- Analysis
- Findings
- Solution
- Feedback for User
- Next Steps

## 3. SPARQL Query Guide

### Basic Query Patterns

1. **Select All Machines**
```sparql
SELECT ?machine WHERE {
    ?machine rdf:type <http://example.org/core#Machine> .
}
```

2. **Get Machine Status**
```sparql
SELECT ?machine ?status WHERE {
    ?machine rdf:type <http://example.org/core#Machine> ;
            <http://example.org/core#hasStatus> ?status .
}
```

3. **Find Sensors Attached to Machines**
```sparql
SELECT ?machine ?sensor ?reading WHERE {
    ?sensor <http://example.org/core#attachedTo> ?machine ;
           <http://example.org/core#latestReading> ?reading .
}
```

### Query Execution
```python
# Using KnowledgeGraphManager
results = await graph_manager.query_graph("""
    SELECT ?machine WHERE {
        ?machine rdf:type <http://example.org/core#Machine> .
    }
""")
```

### Result Handling
```python
# Results are returned as list of dicts with string keys
for result in results:
    machine = result['machine']  # Access using string key
    status = result['status']    # Access using string key
```

## 4. Best Practices

### 1. Always Check Existing Code
```python
# Before writing new code
list_dir <directory>
codebase_search <query>
grep_search <pattern>
```

### 2. Document in scratch_space
- Create analysis files before implementation
- Log all changes and decisions
- Maintain clear documentation of progress
- Use consistent file naming patterns

### 3. Test-Driven Development
- Write tests before implementation
- Cover edge cases
- Test error conditions
- Verify performance
- Document test cases

### 4. Error Handling
```python
try:
    results = await graph_manager.query_graph(sparql_query)
except Exception as e:
    logger.error(f"Error executing SPARQL query: {e}")
    raise
```

## 5. Common Patterns

### 1. Adding Triples
```python
await graph_manager.add_triple(
    "http://example.org/core#MachineC",
    "http://example.org/core#hasStatus",
    "Nominal"
)
```

### 2. Querying with Namespaces
```python
# Use fully qualified URIs
SELECT ?machine WHERE {
    ?machine rdf:type <http://example.org/core#Machine> .
}
```

### 3. Graph Validation
```python
validation = await graph_manager.validate_graph()
print(f"Triple count: {validation['triple_count']}")
print(f"Namespaces: {validation['namespaces']}")
```

## 6. Troubleshooting Guide

### Common Issues
1. **Namespace Errors**
   - Use fully qualified URIs
   - Check namespace bindings
   - Verify prefix declarations

2. **Result Type Mismatches**
   - Convert rdflib.Literal to string: `str(result['status'])`
   - Handle URIRef objects appropriately

3. **Empty Results**
   - Verify data loading
   - Check SPARQL query syntax
   - Confirm namespace bindings

### Debugging Steps
1. Check graph validation
2. Verify data loading
3. Test SPARQL queries directly
4. Review namespace bindings
5. Check result types

## 7. Progress Tracking

### Update Format
```markdown
## Update: [Title] ([Date])

### Test Results
- Passed: [count]
- Failed: [count]
- Details of failures

### Analysis
- Root cause
- Impact
- Solution approach

### Feedback for User
- Key findings
- Recommendations
- Next steps

### Next Steps
1. Action item 1
2. Action item 2
3. Action item 3
```

## 8. Environment-Specific Notes

### Python Version
- Python 3.11.8
- Async/await support
- Type hints

### Dependencies
- RDFLib
- Pytest
- pytest-asyncio
- Loguru

### Project Structure
- Modular design
- Clear separation of concerns
- Comprehensive test coverage

### Testing Framework
- Pytest with async support
- Comprehensive test suite
- Clear test organization 

## 9. Advanced SPARQL Query Patterns

### Complex Query Examples

1. **FILTER with Multiple Conditions**
```sparql
SELECT ?machine ?sensor ?reading ?status WHERE {
    ?sensor <http://example.org/core#attachedTo> ?machine ;
           <http://example.org/core#latestReading> ?reading .
    ?machine <http://example.org/core#hasStatus> ?status .
    FILTER(?reading > 50)
}
```

2. **UNION for Multiple Patterns**
```sparql
SELECT ?entity ?type WHERE {
    {
        ?entity rdf:type <http://example.org/core#Machine> .
        BIND("Machine" as ?type)
    } UNION {
        ?entity rdf:type <http://example.org/core#Sensor> .
        BIND("Sensor" as ?type)
    }
}
```

3. **OPTIONAL for Optional Matches**
```sparql
SELECT ?machine ?status ?sensor ?reading WHERE {
    ?machine rdf:type <http://example.org/core#Machine> ;
            <http://example.org/core#hasStatus> ?status .
    OPTIONAL {
        ?sensor <http://example.org/core#attachedTo> ?machine ;
               <http://example.org/core#latestReading> ?reading .
    }
}
```

4. **GROUP BY with Aggregation**
```sparql
SELECT ?machine (AVG(?reading) as ?avg_reading) WHERE {
    ?sensor <http://example.org/core#attachedTo> ?machine ;
           <http://example.org/core#latestReading> ?reading .
}
GROUP BY ?machine
```

5. **FILTER with Regular Expressions**
```sparql
SELECT ?entity ?type WHERE {
    ?entity rdf:type ?type .
    FILTER(REGEX(str(?entity), "Machine"))
}
```

### Query Execution Tips

1. **Handling Results**
```python
# Results are returned as list of dicts with string keys
for result in results:
    # Handle optional fields
    sensor_info = f", Sensor: {result['sensor']}" if result.get('sensor') else ""
    print(f"Machine: {result['machine']}{sensor_info}")
```

2. **Error Handling**
```python
try:
    results = await graph_manager.query_graph(sparql_query)
except Exception as e:
    logger.error(f"Error executing SPARQL query: {e}")
    raise
```

3. **Query Building**
- Use triple quotes for multi-line queries
- Keep URIs consistent
- Use proper indentation for readability
- Add comments for complex queries

### Common Patterns

1. **Finding Related Entities**
```sparql
SELECT ?entity ?related WHERE {
    ?entity <http://example.org/core#hasRelation> ?related .
}
```

2. **Type Checking**
```sparql
SELECT ?entity WHERE {
    ?entity rdf:type <http://example.org/core#Machine> .
}
```

3. **Property Paths**
```sparql
SELECT ?start ?end WHERE {
    ?start <http://example.org/core#connectsTo>* ?end .
}
```

### Best Practices

1. **Query Organization**
- Group related triple patterns
- Use meaningful variable names
- Add comments for complex logic
- Use proper indentation

2. **Performance**
- Use specific patterns first
- Limit optional matches
- Use appropriate filters
- Consider using property paths

3. **Maintenance**
- Document complex queries
- Use consistent naming
- Keep URIs in constants
- Test queries thoroughly

### Troubleshooting

1. **No Results**
- Check namespace bindings
- Verify data exists
- Test simpler patterns
- Check filter conditions

2. **Unexpected Results**
- Verify triple patterns
- Check filter logic
- Review optional matches
- Test sub-queries

3. **Performance Issues**
- Simplify complex queries
- Add specific filters
- Use appropriate indexes
- Profile query execution 

## Agent Integrity & Transparency Best Practices

- **Never make factless claims:** Always verify test results and implementation status before reporting.
- **Log all incidents and test outcomes:** Use the scratch space to document failures, partial passes, and any issues encountered.
- **Show, don't tell:** When asked for proof, run the relevant commands and display the actual output.
- **Acknowledge and correct mistakes:** If an error or misstatement is made, log it and address it transparently.
- **Prioritize user trust:** The agent's credibility depends on accurate, reproducible, and honest reporting.
- **Document next steps:** Always provide a clear action plan for resolving issues or failures. 

## Agent Integration Pattern (Work Package 2)

### Overview
The `AgentIntegrator` is the central component for connecting agents to the knowledge graph and enabling inter-agent communication. It ensures that all agents share a common `KnowledgeGraphManager` and provides message routing, broadcasting, and status reporting.

### Registering Agents
To connect an agent to the knowledge graph, register it with the integrator:
```python
integrator = AgentIntegrator(kg_manager)
await integrator.register_agent(sensor_agent)
await integrator.register_agent(data_processor_agent)
```
This sets the agent's `knowledge_graph` property and calls its `initialize()` method.

### Message Routing and Broadcasting
- **Routing:**
  Use `await integrator.route_message(message)` to send a message to a specific agent.
- **Broadcasting:**
  Use `await integrator.broadcast_message(message)` to send a message to all agents (except the sender).

### Async/Await Best Practices
- All agent methods that update the knowledge graph (e.g., `update_knowledge_graph`) must `await` async methods like `add_triple`.
- Always use `await` when calling async methods on the `KnowledgeGraphManager` to ensure proper execution and avoid runtime warnings.

### Example Usage
```python
# Initialize
kg_manager = KnowledgeGraphManager()
integrator = AgentIntegrator(kg_manager)
sensor_agent = SensorAgent("sensor_agent")
data_processor_agent = DataProcessorAgent("data_processor_agent")
await integrator.register_agent(sensor_agent)
await integrator.register_agent(data_processor_agent)

# Send a message to SensorAgent
sensor_message = AgentMessage(
    sender="system",
    recipient="sensor_agent",
    content={"sensor_id": "http://example.org/core#Sensor1", "reading": 42.0, "predicate": "http://example.org/core#latestReading"},
    timestamp=time.time(),
    message_type="sensor_update"
)
sensor_response = await integrator.route_message(sensor_message)

# Check knowledge graph
for s, p, o in kg_manager.graph:
    print(s, p, o)
```

### Recommendations for Future Agent Integration
- Always register new agents with the integrator to ensure they are connected to the shared knowledge graph.
- Use the integrator for all inter-agent communication and graph updates.
- Follow async/await best practices for all graph operations.
- Expand the demo script (`scripts/demo_agent_integration.py`) as new agent types and workflows are added.

### References
- Demo script: `scripts/demo_agent_integration.py`
- Progress log: `scratch_space/wp2_progress.md` 