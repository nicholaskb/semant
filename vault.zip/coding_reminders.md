# Critical Coding Reminders

## ALWAYS Look Before You Write
- **RULE #1**: ALWAYS check for existing code before writing new code
- **RULE #2**: ALWAYS check for existing tests before writing new tests
- **RULE #3**: ALWAYS check for existing documentation before writing new docs

## Code Search Checklist
1. Check the relevant directory first (e.g., `kg/models/` for knowledge graph code)
2. Look for similar files or classes that might already implement what you need
3. Read the existing code thoroughly to understand its functionality
4. Check for existing tests to understand the expected behavior
5. Review any documentation or comments in the existing code

## Recent Example (2024-03-19)
- **Mistake**: Started to create a new knowledge graph manager without checking existing code
- **Discovery**: Found existing `KnowledgeGraphManager` class in `kg/models/graph_manager.py`
- **Lesson**: Always search first! The existing implementation already had:
  - Graph initialization and namespace management
  - Triple addition and updates
  - Graph queries
  - Semantic relationships
  - Complex query patterns
  - Comprehensive test suite

## Best Practices
1. Use existing code when possible
2. Extend existing code rather than duplicating
3. Document any extensions or modifications
4. Update tests to cover new functionality
5. Keep the codebase DRY (Don't Repeat Yourself)

## Tools to Use
- `list_dir` to check directory contents
- `read_file` to examine existing code
- `grep_search` to find similar implementations
- `codebase_search` for semantic code search

Remember: Writing new code should be the last resort, not the first step! 