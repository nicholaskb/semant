# Deep Research Agent Prompt: Troubleshooting Gmail API "Precondition Check Failed" Error

## Context
- The agent is using OAuth2 user credentials (`credentials.json` and `token.pickle`) to send email via the Gmail API.
- The code is based on the working `send_gmail_test.py` script, which successfully sends email using OAuth2.
- The agent's email integration (`EmailIntegration` and `VertexEmailAgent`) is set up to use these credentials.
- When running `test_vertex_email.py` or `demo_email.py`, the agent attempts to send an email but receives a "Precondition check failed" error from the Gmail API.
- The error suggests the OAuth token might be expired, invalid, or the service account is not authorized to send as the user.

## Known Information
- OAuth2 credentials (`credentials.json`) are present in the `credentials/` directory.
- A `token.pickle` file exists, indicating a previous OAuth flow was completed.
- The agent code is designed to use OAuth2 for authentication.
- The standalone script `send_gmail_test.py` works correctly and sends email without errors.
- The agent's email integration logic is based on the same OAuth2 flow as `send_gmail_test.py`.

## Questions to Investigate
1. **Is the OAuth token expired or invalid?**
   - Check if `token.pickle` is up-to-date. If not, re-run the OAuth flow.
   - Verify if the token is being loaded correctly in the agent's code.

2. **Is the agent using the correct credentials?**
   - Ensure the agent is using `credentials.json` and `token.pickle`, not a service account.
   - Check if the environment variables or code paths are correctly pointing to these files.

3. **Is the Gmail API properly enabled and configured?**
   - Verify the Gmail API is enabled in the Google Cloud Console.
   - Check if the OAuth consent screen is configured correctly.

4. **Are there any Google Workspace or domain-wide delegation settings?**
   - If using a Google Workspace domain, ensure domain-wide delegation is set up and the service account is authorized to send as the user.
   - If using a personal Gmail account, ensure OAuth2 is used, not a service account.

5. **Is the agent's code correctly handling OAuth2?**
   - Compare the agent's OAuth2 logic with the working `send_gmail_test.py` script.
   - Ensure the agent is refreshing the token if it's expired.

## Steps to Resolve
1. **Re-run the OAuth flow:**
   - Delete `token.pickle`.
   - Run the agent's email script again to trigger the OAuth flow.
   - Log in and authorize the app to generate a new token.

2. **Verify the agent's code:**
   - Ensure the agent is using the same OAuth2 logic as `send_gmail_test.py`.
   - Check if the agent is correctly loading and using `credentials.json` and `token.pickle`.

3. **Check Google Cloud Console settings:**
   - Ensure the Gmail API is enabled.
   - Verify the OAuth consent screen is configured correctly.
   - If using a Google Workspace domain, check domain-wide delegation settings.

4. **Test with the standalone script:**
   - Run `send_gmail_test.py` to verify the OAuth flow works independently.
   - If it works, compare its logic with the agent's code to identify discrepancies.

5. **Log and document all findings:**
   - Record all steps, errors, and solutions in the scratch space.
   - Update the documentation to reflect the correct setup and troubleshooting steps.

## Expected Outcome
- The agent should successfully send email using OAuth2 user credentials.
- The "Precondition check failed" error should be resolved.
- The agent's email integration should work consistently, just like the standalone script.

## Additional Notes
- If the issue persists, consider using the standalone script (`send_gmail_test.py`) for email sending until the agent's integration is fixed.
- Ensure all changes and findings are logged in the scratch space for future reference.

---

This prompt is designed to guide the Deep Research Agent in thoroughly investigating and resolving the Gmail API "Precondition check failed" error, ensuring the agent can successfully send email using OAuth2. 