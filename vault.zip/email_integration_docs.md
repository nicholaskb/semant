# Email Integration Documentation

## Overview
The email integration system provides a unified interface for sending emails through the Gmail API with optional Vertex AI enhancement. The system is designed to be both standalone and integrated with the main agent system.

## Components

### 1. EmailIntegration Class
Located in `email_integration.py`, this class provides the core email functionality:
- Initialization of the VertexEmailAgent
- Email sending with error handling
- Logging and status reporting

### 2. MainAgent Integration
The `MainAgent` class includes email capabilities through the `EmailIntegration` class:
- Automatic initialization during agent startup
- Email sending through the agent interface
- Integration with the knowledge graph for email tracking

## Usage Examples

### Standalone Usage
```python
from email_integration import EmailIntegration

async def send_test_email():
    email = EmailIntegration()
    result = await email.send_email(
        to="recipient@example.com",
        subject="Test Email",
        body="This is a test email"
    )
    print(result)
```

### MainAgent Usage
```python
from main_agent import MainAgent

async def send_email_with_main_agent():
    agent = MainAgent()
    await agent.initialize()
    result = await agent.send_email(
        to="recipient@example.com",
        subject="Test Email from Main Agent",
        body="This is a test email from the main agent"
    )
    print(result)
```

## Configuration

### Required Environment Variables
Add these to your `.env` file:
```
GOOGLE_CLOUD_PROJECT=your-project-id
GOOGLE_CLOUD_LOCATION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=path/to/your/credentials.json
```

### Gmail API Setup
1. Enable the Gmail API in your Google Cloud Console
2. Create OAuth 2.0 credentials
3. Download the credentials and save as `credentials/credentials.json`

## Error Handling

The system provides detailed error reporting:
```python
{
    "status": "error",
    "message": "Error description",
    "details": "Detailed error information"
}
```

## Logging

All email operations are logged using the logger:
- Successful sends: `INFO` level
- Errors: `ERROR` level
- Initialization: `INFO` level

## Testing

Run the email integration tests:
```bash
python -m pytest tests/unit/test_vertex_email_agent.py -v
```

## Recent Changes
- Added email integration to MainAgent
- Implemented error handling and logging
- Added documentation in README and scratch space
- Created test suite for email functionality

## Future Enhancements
1. Add email templates
2. Implement email scheduling
3. Add support for attachments
4. Enhance Vertex AI integration for better content generation

## Recent Bug Fixes
- Fixed missing `timestamp` in `AgentMessage` instantiation in `EmailIntegration`. This resolves Pydantic validation errors during email sending.

## Comprehensive Testing
- Added tests for:
  - Valid email send
  - Invalid recipient
  - Missing subject
  - Missing body
  - Error handling
- See `scratch_space/test_email_send.py` for test cases and usage.

## Usage Notes
- Ensure all required fields are set when creating `AgentMessage`.
- Use `time.time()` for the timestamp.

## Troubleshooting
- **Validation error for AgentMessage**: Ensure `timestamp` is provided.
- **Gmail API errors**: Check credentials, API enablement, and recipient address format.
- **Permission errors**: Verify service account roles and OAuth scopes.

## [2024-05-30] User Confirmation and OAuth2 Setup
- User confirmed that `credentials/credentials.json` is present, even though it is not visible to the agent.
- This means the Gmail API integration will use OAuth2 user credentials for sending email.
- All future email sends will use this authentication method unless the environment or code changes.
- This log entry was made at the user's request for traceability.

## [2024-05-30] Reminder: Always Check Existing Code and Documentation
- Before writing new scripts or code, always check:
  - The README for project overview and setup instructions.
  - The scratch space for existing scripts, logs, and documentation.
  - Any existing scripts (e.g., `send_gmail_test.py`, `test_email_send.py`, etc.) to avoid duplication.
- This ensures we build on existing work and maintain consistency.
- This log entry was added to prevent future oversight.

## [2024-05-30] Found Existing Vertex Agent Email Script
- The script `scratch_space/test_vertex_email.py` already has a method (`test_vertex_email()`) for the Vertex agent to send an email.
- This script uses the `EmailIntegration` class and sends a test email with Vertex AI enhancement.
- We can reuse or extend this script to have the agent 'say hi from the knowledge graph'.
- This log entry was added to ensure we build on existing work and avoid duplication. 