Subject: Request for Help with Gmail API "Precondition Check Failed" Error

Hi Sam,

I hope this message finds you well. I'm reaching out because I'm encountering a "Precondition check failed" error when trying to send emails using the Gmail API in our agent's integrated scripts. The standalone script `send_gmail_test.py` works fine, but the integrated scripts (`test_vertex_email.py`, `demo_email.py`) are failing.

Here's a bit of context:
- We're using OAuth2 user credentials (`credentials.json` and `token.pickle`).
- The error suggests the OAuth token might be expired, invalid, or the service account is not authorized to send as the user.

Could you help me investigate the following:
1. Are the failing scripts being run in a different environment compared to the working script?
2. Do the failing scripts perform any additional Gmail API actions before sending?
3. Are the failing scripts being triggered by another agent or automated process?
4. Do the scripts all use the exact same OAuth scopes, especially `https://www.googleapis.com/auth/gmail.send`?

Any insights or suggestions you might have would be greatly appreciated. Thanks in advance for your help!

Best regards,
[Your Name] 