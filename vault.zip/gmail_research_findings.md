# Gmail API Integration Research Findings

## Current State Analysis

### 1. Project Configuration
- Project ID: semant-vertex-ai
- Service Account: semant-vertex-sa@semant-vertex-ai.iam.gserviceaccount.com
- User Account: nicholas.k.baro@gmail.com
- Location: us-central1

### 2. API Status
- Gmail API: Not Enabled
- Error: Project configuration issue with gcloud
- Current gcloud configuration: [bahroo]

### 3. Credentials Status
1. Service Account:
   - Found at: /Users/nicholasbaro/Python/semant/credentials.json
   - Email: semant-vertex-sa@semant-vertex-ai.iam.gserviceaccount.com
   - Project ID: semant-vertex-ai

2. OAuth Credentials:
   - Not found at: credentials/credentials.json
   - Token file: Not created (normal for first-time setup)

### 4. Environment Variables
- GOOGLE_CLOUD_PROJECT: semant-vertex-ai
- GOOGLE_APPLICATION_CREDENTIALS: $(pwd)/credentials.json
- GOOGLE_CLOUD_LOCATION: us-central1

## Identified Issues

### 1. Project Configuration
- gcloud configuration is not properly set
- Project ID format is incorrect in gcloud config
- Need to fix project configuration before proceeding

### 2. API Enablement
- Gmail API is not enabled in the project
- Cannot verify API status due to project configuration issues
- Need to enable API after fixing project configuration

### 3. Authentication Setup
- Service account exists but permissions need verification
- OAuth credentials are missing
- OAuth consent screen not configured
- Token storage not set up

### 4. Implementation Issues
- Current code assumes OAuth credentials exist
- Error handling needs improvement
- Token refresh mechanism not implemented
- Security best practices not fully implemented

## Required Actions

### 1. Fix Project Configuration
```bash
# Set correct project ID
gcloud config set project semant-vertex-ai

# Verify configuration
gcloud config list
```

### 2. Enable Gmail API
```bash
# Enable Gmail API
gcloud services enable gmail.googleapis.com --project=semant-vertex-ai
```

### 3. Set Up OAuth
1. Configure OAuth Consent Screen:
   - Go to Google Cloud Console
   - Navigate to APIs & Services > OAuth consent screen
   - Set up application information
   - Add required scopes

2. Create OAuth Credentials:
   - Go to APIs & Services > Credentials
   - Create OAuth 2.0 Client ID
   - Choose Desktop application
   - Download credentials
   - Save as credentials/credentials.json

### 4. Configure Service Account
1. Verify current permissions:
   ```bash
   gcloud projects get-iam-policy semant-vertex-ai \
     --flatten=bindings[].members \
     --format=table(bindings.role,bindings.members) \
     --filter=bindings.members:semant-vertex-sa@semant-vertex-ai.iam.gserviceaccount.com
   ```

2. Add required roles:
   ```bash
   gcloud projects add-iam-policy-binding semant-vertex-ai \
     --member=serviceAccount:semant-vertex-sa@semant-vertex-ai.iam.gserviceaccount.com \
     --role=roles/gmail.api
   ```

## Implementation Recommendations

### 1. Authentication Flow
```python
# Recommended authentication flow
def get_credentials():
    """Get Gmail API credentials."""
    creds = None
    token_path = 'credentials/token.pickle'
    
    # Load existing token
    if os.path.exists(token_path):
        with open(token_path, 'rb') as token:
            creds = pickle.load(token)
    
    # Refresh or get new token
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials/credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        
        # Save token
        with open(token_path, 'wb') as token:
            pickle.dump(creds, token)
    
    return creds
```

### 2. Error Handling
```python
# Improved error handling
def send_email(service, user_id, message):
    """Send an email with proper error handling."""
    try:
        message = service.users().messages().send(
            userId=user_id, body=message).execute()
        logger.info(f"Message Id: {message['id']}")
        return message
    except HttpError as error:
        if error.resp.status == 403:
            logger.error("Permission denied. Check OAuth scopes and credentials.")
        elif error.resp.status == 404:
            logger.error("Gmail API not found. Check API enablement.")
        else:
            logger.error(f"An error occurred: {error}")
        return None
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        return None
```

### 3. Security Best Practices
1. Token Storage:
   - Store tokens in secure location
   - Set proper file permissions (600)
   - Implement token refresh mechanism
   - Handle token expiration

2. Credential Management:
   - Use environment variables for sensitive data
   - Implement proper error handling
   - Log security-relevant events
   - Follow principle of least privilege

## Testing Strategy

### 1. Configuration Tests
- Verify project configuration
- Check API enablement
- Validate credentials
- Test token storage

### 2. Authentication Tests
- Test OAuth flow
- Verify token refresh
- Check error handling
- Validate permissions

### 3. Integration Tests
- Test email sending
- Verify error handling
- Check logging
- Validate security measures

## Next Steps
1. Fix project configuration
2. Enable Gmail API
3. Set up OAuth consent screen
4. Create OAuth credentials
5. Configure service account
6. Implement recommended changes
7. Run verification tests
8. Document solution

## References
- [Gmail API Documentation](https://developers.google.com/gmail/api/guides)
- [OAuth 2.0 for Desktop Apps](https://developers.google.com/identity/protocols/oauth2/native-app)
- [Service Account Best Practices](https://cloud.google.com/iam/docs/best-practices-for-managing-service-account-keys)
- [Gmail API Scopes](https://developers.google.com/gmail/api/auth/scopes) 