# Knowledge Graph Update Plan

## Current State
- WatchdogAgent implementation complete
- Basic fault tolerance classes and properties defined
- Initial agent instances created

## Required Updates

### 1. Agent Status Tracking
```sparql
# Query to verify agent status
SELECT ?agent ?status ?lastCheck WHERE {
    ?agent rdf:type ex:Agent .
    ?agent ex:hasStatus ?status .
    ?agent ex:hasLastHealthCheck ?lastCheck .
}
```

### 2. Task State Management
```sparql
# Query to verify task states
SELECT ?task ?status ?assignedTo ?lastUpdated WHERE {
    ?task rdf:type ex:Task .
    ?task ex:hasStatus ?status .
    OPTIONAL { ?task ex:assignedTo ?assignedTo }
    ?task ex:hasLastUpdated ?lastUpdated .
}
```

### 3. Recovery Strategy Verification
```sparql
# Query to verify recovery strategies
SELECT ?agent ?strategy ?failureCount WHERE {
    ?agent rdf:type ex:Agent .
    ?agent ex:hasRecoveryStrategy ?strategy .
    ?agent ex:hasFailureCount ?failureCount .
}
```

## Update Process

1. Agent Status Updates
   - Add `hasLastHealthCheck` to all agents
   - Set initial health status
   - Track failure counts

2. Task State Updates
   - Add timeout values
   - Track last update times
   - Link to assigned agents

3. Recovery Strategy Updates
   - Define recovery strategies
   - Set failure thresholds
   - Link to monitoring agents

## Verification Tests

```python
def test_agent_status_updates():
    """Test agent status tracking in knowledge graph."""
    # Setup
    graph = Graph()
    agent = URIRef("ex:Agent5")
    
    # Add status
    graph.add((agent, URIRef("ex:hasStatus"), Literal("Failed")))
    graph.add((agent, URIRef("ex:hasFailureCount"), Literal(1)))
    
    # Verify
    status = graph.value(agent, URIRef("ex:hasStatus"))
    assert status == "Failed"
    
    failure_count = graph.value(agent, URIRef("ex:hasFailureCount"))
    assert failure_count == 1

def test_task_state_updates():
    """Test task state management in knowledge graph."""
    # Setup
    graph = Graph()
    task = URIRef("ex:Task4")
    
    # Add state
    graph.add((task, URIRef("ex:hasStatus"), Literal("InProgress")))
    graph.add((task, URIRef("ex:hasTimeout"), Literal(3600)))
    
    # Verify
    status = graph.value(task, URIRef("ex:hasStatus"))
    assert status == "InProgress"
    
    timeout = graph.value(task, URIRef("ex:hasTimeout"))
    assert timeout == 3600

def test_recovery_strategy_updates():
    """Test recovery strategy updates in knowledge graph."""
    # Setup
    graph = Graph()
    agent = URIRef("ex:WatchdogAgent1")
    
    # Add strategy
    graph.add((agent, URIRef("ex:hasRecoveryStrategy"), 
              Literal("RestartAndReassign")))
    
    # Verify
    strategy = graph.value(agent, URIRef("ex:hasRecoveryStrategy"))
    assert strategy == "RestartAndReassign"
```

## Integration Points

1. WatchdogAgent Integration
   - Update task states
   - Track timeouts
   - Record reassignments

2. HealthMonitor Integration
   - Update agent health
   - Track failures
   - Record restarts

3. DataConsistencyChecker Integration
   - Verify relationships
   - Track inconsistencies
   - Record repairs

## Next Steps
1. Implement verification tests
2. Add monitoring queries
3. Create update scripts
4. Document update procedures 