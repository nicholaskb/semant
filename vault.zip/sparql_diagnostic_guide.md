# SPARQL Diagnostic & Technical Agent Guide

## Overview
This guide is a comprehensive resource for diagnosing, debugging, and documenting issues in agentic multi-agent systems using SPARQL, the knowledge graph, diagnostic scripts, and the scratch space. It is designed for use by both human and agentic coding teams.

---

## Quick Start
1. **Load Sample Data:**
   ```bash
   python scratch_space/load_sample_data.py
   ```
2. **Run Diagnostic Queries:**
   ```bash
   python scratch_space/kg_swarm_proof.py
   ```
3. **Log Observations:**
   - Use `scratch_space/wp1_progress.md` to document findings, queries, and results.

---

## Core Diagnostic Queries

### 1. Agent-Capability Relationships
```sparql
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX core: <http://example.org/core#>
SELECT ?agent ?capability WHERE {
  ?agent rdf:type core:Agent .
  ?agent core:hasCapability ?capability .
}
```

### 2. Empty Capability Detection
```sparql
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX core: <http://example.org/core#>
SELECT ?agent WHERE {
  ?agent rdf:type core:Agent .
  FILTER NOT EXISTS { ?agent core:hasCapability ?capability }
}
```

### 3. Capability Type Validation
```sparql
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX core: <http://example.org/core#>
SELECT ?capability WHERE {
  ?capability rdf:type ?type .
  FILTER(?type != core:Capability)
}
```

### 4. Duplicate Capability Check
```sparql
PREFIX core: <http://example.org/core#>
SELECT ?agent ?capability (COUNT(?capability) AS ?count) WHERE {
  ?agent core:hasCapability ?capability .
}
GROUP BY ?agent ?capability
HAVING (?count > 1)
```

### 5. Event Propagation Check
```sparql
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX core: <http://example.org/core#>
SELECT ?event ?agent ?capability WHERE {
  ?event rdf:type core:CapabilityChangeEvent .
  ?event core:affectedAgent ?agent .
  ?event core:affectedCapability ?capability .
}
```

---

## Deep Debugging & Advanced Queries

### 6. List All Triples (Raw Inspection)
```sparql
SELECT ?s ?p ?o WHERE { ?s ?p ?o }
```
*Use this to see all data in the graph and spot unexpected triples or missing data.*

### 7. List All Namespaces
```python
# Python code
for prefix, ns in kg.graph.namespaces():
    print(f"{prefix}: {ns}")
```
*Use this to verify that all prefixes are correctly bound and used in queries.*

### 8. Orphan Node Detection (Nodes with no incoming/outgoing edges)
```sparql
SELECT ?node WHERE {
  ?node ?p ?o .
  FILTER NOT EXISTS { ?s ?any ?node }
}
```
*Finds nodes that are only subjects, never objects (potentially incomplete data).* 

### 9. Literal vs URI Type Check
```sparql
SELECT ?agent ?capability WHERE {
  ?agent <http://example.org/core#hasCapability> ?capability .
  FILTER(isLiteral(?capability))
}
```
*Detects if any capabilities are stored as literals instead of URIs (should always be URIs).* 

### 10. Cache Validation (Python)
```python
# Python code
cache_keys = await kg.cache.keys()
print("Cached queries:", cache_keys)
```
*Ensures that cache is being invalidated and updated as expected after graph changes.*

### 11. Triple Count and Graph Stats
```python
stats = await kg.get_stats()
print(stats)
```
*Check triple count, cache hits/misses, and other metrics for graph health.*

### 12. Version/History Inspection
```python
print(kg.version_tracker.versions)
```
*See all historical versions of the graph for rollback/debugging.*

---

## Troubleshooting Patterns

- **No Results in Queries:**
  - Check for correct namespace prefixes in both data and queries.
  - Use the raw triple query to inspect actual data.
  - Verify that data is loaded before querying.
- **Unexpected Data Types:**
  - Use the literal vs URI check to ensure all relationships are typed correctly.
- **Orphan/Disconnected Nodes:**
  - Use the orphan node query to find incomplete or isolated data.
- **Cache Issues:**
  - Validate cache keys and clear cache if results are stale.
- **Event/Notification Issues:**
  - Use event propagation queries to ensure events are being logged and linked.

---

## Collaborative Diagnosis with Scratch Space

- **Log Every Query and Result:**
  - Paste SPARQL queries and their outputs into `scratch_space/wp1_progress.md`.
- **Document Hypotheses and Fixes:**
  - Record what you think is wrong, what you changed, and the observed effect.
- **Peer Review:**
  - Use the scratch space to request and record feedback from other agents.
- **Track Progress:**
  - Summarize what's been tried, what worked, and what's next.

---

## Exhaustive Technical Diagnosis Workflow

1. **Data Load & Verification**
   - Load sample or real data.
   - Run the raw triple query to confirm data presence.
   - List namespaces to ensure correct bindings.
2. **Basic Health Checks**
   - Run all core diagnostic queries (1-5 above).
   - Log results in scratch space.
3. **Deep Debugging**
   - Use advanced queries (6-12) to inspect graph structure, types, cache, and history.
   - Investigate any anomalies found.
4. **Iterative Fix & Validate**
   - Make targeted code/data changes.
   - Re-run relevant queries and scripts.
   - Log before/after results.
5. **Collaborative Review**
   - Share findings and logs in scratch space.
   - Solicit feedback and peer review.
   - Update documentation and guides as needed.
6. **Final Validation**
   - Ensure all queries return expected results.
   - Confirm no orphan nodes, type mismatches, or stale cache.
   - All changes and findings are documented and peer-reviewed.

---

## Best Practices
- Always use explicit prefixes in SPARQL queries.
- Validate data presence with raw triple queries before deeper checks.
- Use the scratch space for all collaborative diagnosis and documentation.
- Keep the guide and queries up to date as the ontology and system evolve.
- Share new patterns and findings with the team.

---

## Example: Full Debugging Session

1. Load data:
   ```bash
   python scratch_space/load_sample_data.py
   ```
2. List all triples:
   ```sparql
   SELECT ?s ?p ?o WHERE { ?s ?p ?o }
   ```
3. List namespaces (Python):
   ```python
   for prefix, ns in kg.graph.namespaces():
       print(f"{prefix}: {ns}")
   ```
4. Run all core and advanced queries.
5. Log all queries and results in `scratch_space/wp1_progress.md`.
6. Discuss findings with the team and iterate as needed.

---

## Sample Data Clarification
- The sample data loader only adds `Agent1` as an agent (`rdf:type core:Agent`) and `CAP_A`, `CAP_B` as capabilities (`rdf:type core:Capability`).
- If you see any other resource (e.g., `Agent1`) in the "Capabilities with Wrong Type" query, check for stale data or bugs in your triple addition logic.

## Troubleshooting (add to existing section)
- If an agent appears as a capability:
  - Check for accidental triple insertion with `rdf:type core:Capability` for that agent.
  - Verify the data loader logic to ensure only intended resources are typed as capabilities.
  - Clear any persistent or cached data before re-running tests.

**This guide is intended to be a living document. Update it as new issues, queries, and best practices emerge!** 