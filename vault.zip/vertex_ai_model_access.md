# Vertex AI Model Access Troubleshooting

## Current Status
- Project: `semant-vertex-ai`
- Service Account: `semant-vertex-sa@semant-vertex-ai.iam.gserviceaccount.com`
- Required Roles: 
  - `roles/aiplatform.user`
  - `roles/serviceusage.serviceUsageViewer`

## Model Access Strategy
1. **Global Location First**
   - Using `location="global"` as recommended for Gemini models
   - Testing with `gemini-2.0-flash-001` (latest stable version)
   - Fallback to `gemini-1.5-pro` if needed

2. **Regional Fallback**
   - Testing regions: `us-central1`, `us-east4`, `us-west4`
   - Same model versions as global location

## Recent Changes
1. Updated test script to:
   - Try global location first
   - Use correct model IDs (`gemini-2.0-flash-001`, `gemini-1.5-pro`)
   - Improved error logging and handling

## Test Results (2025-05-30)
✅ **All tests passed successfully:**
1. Environment Variables: Verified
2. Service Account Credentials: Loaded successfully
3. API Enablement: Vertex AI API is enabled
4. Vertex AI Initialization: Successful in us-central1
5. Model Access: Successfully accessed `gemini-2.0-flash-001` in us-central1

**Note:** Global location initialization failed (not supported), but regional access in us-central1 works perfectly.

## Working Configuration
- Location: `us-central1`
- Model: `gemini-2.0-flash-001`
- API: Enabled and accessible
- Permissions: Correctly configured

## Next Steps
1. Run updated integration tests
2. If tests fail:
   - Verify API enablement
   - Check model availability in project
   - Consider requesting access to specific models

## References
- [Vertex AI Model Availability](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/model-versions)
- [Regional Endpoints](https://cloud.google.com/vertex-ai/generative-ai/docs/learn/locations)
- [IAM Roles](https://cloud.google.com/vertex-ai/docs/general/access-control) 