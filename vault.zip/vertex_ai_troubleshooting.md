> **Note:** This scratch space file is listed in `.gitignore`. As a result, the troubleshooting logs, research notes, and other content here remain local and are not committed to version control. Other agents or collaborators will not see these notes unless explicitly shared.

# Vertex AI Authentication Troubleshooting Guide

## [Current Date] - Model Access Confirmed

- Model access to `text-bison@002` is now confirmed and operational.
- The script `check_vertex_models.py` verifies model access programmatically.
- All authentication, billing, and model access steps are passing.
- Vertex AI is ready for production use.

## [Update: Authentication and Billing Enabled, Model Access Required]

- The authentication issue was resolved by expanding `$(pwd)` in the credentials path in the test script.
- The `.env` file can use `GOOGLE_APPLICATION_CREDENTIALS=$(pwd)/credentials.json` or a static path like `credentials/baa-roo-credentials.json`.
- The test script `scratch_space/test_vertex_auth.py` now handles path expansion and verifies all steps.
- Billing is enabled for project `semant-vertex-ai` using account `00109C-A9F3DC-9EA45D`.
- **New Issue**: Need to enable Vertex AI API and request access to the text-bison model.
- See `scratch_space/vertex_ai_auth_diary.md` for a detailed log of the troubleshooting and resolution process.

## [Current Date] - Deep Research Agent Prompt: Vertex AI Permission Issue

### Context
- The service account is authenticated and billing is enabled.
- Vertex AI API is enabled and the `text-bison@002` model is accessible.
- All tests pass except for email enhancement, which fails with:
  - `403 Permission 'aiplatform.endpoints.predict' denied on resource '//aiplatform.googleapis.com/projects/baa-roo/locations/us-central1/publishers/google/models/text-bison@002'`
- The service account has `Vertex AI User` and `Vertex AI Model User` roles, but the error persists.

### Prompt for Deep Research Agent

**Prompt:**

We are integrating Google Vertex AI (text-bison@002) into a Python application. Authentication, billing, and API enablement are confirmed. However, when attempting to generate text, we receive the following error:

```
403 Permission 'aiplatform.endpoints.predict' denied on resource '//aiplatform.googleapis.com/projects/baa-roo/locations/us-central1/publishers/google/models/text-bison@002'
```

- The service account has both `Vertex AI User` and `Vertex AI Model User` roles.
- The credentials file is valid and loaded.
- All other Vertex AI API calls (initialization, model listing) succeed.
- Only the prediction endpoint is denied.

**What additional permissions, roles, or configuration are required to resolve this error and enable text generation with Vertex AI models? Please provide step-by-step instructions and reference any relevant Google Cloud documentation.**

---

### Feedback / Results from Deep Research Agent

- [ ] (Log feedback and results here)

---

## Common Issues and Solutions

### 1. Environment Variables Not Loaded

**Symptoms:**
- "Unable to authenticate your request" error
- GOOGLE_APPLICATION_CREDENTIALS not found
- Project ID missing

**Solutions:**
```python
# Add at the start of your application
from dotenv import load_dotenv
import os

load_dotenv()  # Load .env file

# Debug environment variables
print("GCP Credentials path:", os.getenv("GOOGLE_APPLICATION_CREDENTIALS"))
print("GCP Project ID:", os.getenv("GOOGLE_CLOUD_PROJECT"))
```

### 2. Missing Project ID

**Symptoms:**
- "Unable to find your project" error
- Authentication fails despite valid credentials

**Solutions:**
```python
import vertexai

# Explicit initialization with project and location
vertexai.init(
    project="your-project-id",
    location="your-region",
    credentials=credentials  # Optional: explicit credentials
)
```

### 3. Incorrect Credential Source

**Symptoms:**
- Authentication works with gcloud but fails in code
- Inconsistent authentication behavior

**Solutions:**
```python
from google.oauth2 import service_account
import vertexai

# Explicit credential loading
credentials = service_account.Credentials.from_service_account_file(
    "/path/to/key.json"
)
vertexai.init(
    project="your-project-id",
    location="your-region",
    credentials=credentials
)
```

### 4. Credential File Issues

**Symptoms:**
- File not found errors
- Permission denied errors
- Silent authentication failures

**Solutions:**
1. Verify file path:
```bash
ls -l $GOOGLE_APPLICATION_CREDENTIALS
```

2. Check file permissions:
```bash
chmod 600 /path/to/service-account.json
```

### 5. Library Version Mismatch

**Symptoms:**
- Unexpected authentication behavior
- Incompatible API calls

**Solutions:**
1. Check versions:
```bash
pip show google-cloud-aiplatform vertexai
```

2. Update packages:
```bash
pip install --upgrade google-cloud-aiplatform vertexai
```

### 6. Model Access Issues

**Symptoms:**
- "Publisher Model not found" error
- "Project does not have access" error
- 404 errors when trying to use Vertex AI models

**Solutions:**
1. Enable Vertex AI API:
```bash
gcloud services enable aiplatform.googleapis.com
```

2. Request access to specific models:
   - Visit [Vertex AI Model Garden](https://console.cloud.google.com/vertex-ai/model-garden)
   - Select the model you need (e.g., text-bison)
   - Click "Enable" or "Request Access"

3. Verify model version:
```python
# Check available model versions
from vertexai.preview.generative_models import GenerativeModel

# List available models
models = GenerativeModel.list_models()
print(models)
```

## Best Practices

### Environment Management

1. **Store Configuration in Environment Variables**
   - Use .env for local development
   - Use Secret Manager for production
   - Never commit credentials to version control

2. **Secure Credential Handling**
   - Use minimal IAM roles
   - Rotate keys periodically
   - Implement proper error handling

3. **Debug Environments**
   - Verify running user/account
   - Check environment variables
   - Test authentication explicitly

### Code Implementation

1. **Proper Initialization**
```python
import os
from dotenv import load_dotenv
from google.oauth2 import service_account
import vertexai

# Load environment variables
load_dotenv()

# Initialize Vertex AI
credentials = service_account.Credentials.from_service_account_file(
    os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
)
vertexai.init(
    project=os.getenv("GOOGLE_CLOUD_PROJECT"),
    location="us-central1",  # or your preferred region
    credentials=credentials
)
```

2. **Error Handling**
```python
try:
    # Vertex AI operations
    response = model.predict(...)
except Exception as e:
    logger.error(f"Vertex AI error: {str(e)}")
    # Handle error appropriately
```

## Testing Authentication

1. **Verify Environment Variables**
```python
def verify_environment():
    required_vars = [
        "GOOGLE_APPLICATION_CREDENTIALS",
        "GOOGLE_CLOUD_PROJECT"
    ]
    for var in required_vars:
        if not os.getenv(var):
            raise ValueError(f"Missing required environment variable: {var}")
```

2. **Test Credential Loading**
```python
def test_credentials():
    try:
        credentials = service_account.Credentials.from_service_account_file(
            os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
        )
        return True
    except Exception as e:
        logger.error(f"Credential loading failed: {str(e)}")
        return False
```

## References

1. [Google Cloud Vertex AI Authentication Guide](https://cloud.google.com/vertex-ai/docs/authentication)
2. [Python-dotenv Best Practices](https://dagster.io/blog/python-environment-variables)
3. [Twelve-Factor App Configuration](https://12factor.net/config)
4. [Google Cloud Secret Manager Guide](https://cloud.google.com/secret-manager/docs/overview)
5. [Vertex AI Model Access Documentation](https://cloud.google.com/vertex-ai/docs/generative-ai/learn/models)

#### Clarifications for Deep Research Agent

- The service account is for the same project (`baa-roo`).
- The general Vertex AI API (`aiplatform.googleapis.com`) is enabled; if a separate Model Prediction API exists, please specify.
- The code uses `GenerativeModel("text-bison@002")` from `vertexai.preview.generative_models` and calls `.predict()`. 

## [Current Date] - Ongoing Research Log: 403 Permission Denied on Vertex AI Publisher Models

### Issue Summary
- **Error:** 403 Permission 'aiplatform.endpoints.predict' denied on resource '//aiplatform.googleapis.com/projects/baa-roo/locations/us-central1/publishers/google/models/text-bison@002'
- **Context:**
  - Service account is in the same project (`baa-roo`)
  - Roles assigned: `Vertex AI User`, `Vertex AI Model User`
  - Vertex AI API enabled, billing enabled, model access confirmed
  - Only prediction endpoint is denied; all other API calls succeed

### Research Actions
- Searched for: `aiplatform.endpoints.predict` permission, IAM_PERMISSION_DENIED, Vertex AI publisher/foundation model permissions, Model Garden access, Unified Model APIs
- Consulted sources:
  - Google Cloud Community
  - StackOverflow
  - Reddit
  - Google Cloud documentation (IAM roles, permissions, Model Garden, Generative AI access control)
- Examined:
  - Vertex AI roles and permissions (including `endpointPredictor` and related roles)
  - Access control for Generative AI and foundation models
  - Differences between project-owned models and Google publisher/foundation models

### Key Findings (So Far)
- Standard roles (`aiplatform.user`, `aiplatform.modelUser`) may not grant prediction access to publisher/foundation models (e.g., text-bison) in Model Garden.
- Publisher/foundation models may require additional or special permissions not documented in standard IAM role lists.
- Some community threads suggest that access to prediction on publisher models is controlled separately from project-owned models, possibly requiring a support request or explicit enablement by Google.
- No clear documentation found yet that lists the exact permission or role for `aiplatform.endpoints.predict` on publisher models.

### Key Terms/Concepts
- `aiplatform.endpoints.predict`
- IAM_PERMISSION_DENIED
- Vertex AI User, Vertex AI Model User, endpointPredictor
- Foundation models, Model Garden, Unified Model APIs
- Publisher models vs. project-owned models

### Next Steps
- Continue searching for explicit documentation or authoritative community answers regarding the required IAM role/permission for prediction on publisher models.
- Look for any recent Google announcements or release notes about Model Garden/foundation model access control.
- If no solution is found, prepare a detailed support request to Google Cloud, including all context, error messages, and steps taken.
- Log any new findings, answers, or workarounds here for future reference.

---

## Resolution Guide: 403 Permission Denied on Vertex AI Publisher Models

### Root Cause
- The error indicates that the service account lacks the `aiplatform.endpoints.predict` permission on the text-bison model resource.
- In Vertex AI, calling a publisher model's predict is treated like invoking an endpoint, so it requires the `aiplatform.endpoints.predict` permission on that model's resource.
- By default, the Vertex AI User role (`roles/aiplatform.user`) and Model User (`roles/aiplatform.modelUser`) must grant this, but in this case, the permission was effectively missing.
- Furthermore, `text-bison@002` is a PaLM-2 foundation model that has been deprecated. As of Oct 9, 2024, new projects cannot access PaLM2 models (including text-bison), and all PaLM2 model access is revoked after April 9, 2025. If this is a newly created project or the model wasn't explicitly enabled for the project, that restriction can cause a 403 as well.

### Required Permissions
- To invoke a publisher-hosted generative model (like text-bison), you must have `aiplatform.endpoints.predict` on the target model.
- The built‑in Vertex AI User role includes this permission. Thus, ensure the service account is granted `roles/aiplatform.user` (and typically `roles/aiplatform.modelUser`).
- In practice, many users also grant Vertex AI Administrator (`roles/aiplatform.admin`) to cover all Vertex AI prediction permissions.
- In short, the service account needs a role that contains `aiplatform.endpoints.predict`. If running locally or in a notebook, make sure you authenticate with that service account (for example via `gcloud auth application-default login`).

### Resolution Steps
1. **Grant Vertex AI roles:** In the GCP Console IAM page, add the Vertex AI User role (`roles/aiplatform.user`) to the service account. This role includes `aiplatform.endpoints.predict`. If the error persists, also add Vertex AI Administrator (`roles/aiplatform.admin`) as a test (it covers all Vertex AI permissions).
2. **Verify authentication:** Ensure the application is actually using the intended credentials. For local testing, run `gcloud auth application-default login` or activate the service-account JSON key so that Vertex AI sees the granted roles.
3. **Check project/model access:** Confirm that your GCP project is allowed to use the text-bison model. As noted by Google, new projects (created after Oct 9, 2024) can no longer use PaLM-2 models like text-bison. If your project is new or not already allowlisted, you must either switch to an available model (for example, Gemini-series models) or request inclusion via Google Cloud Support.
4. **Test with a simple call:** After granting roles, try a minimal predict call. For example:
   ```python
   from vertexai import aiplatform
   aiplatform.init(project="YOUR_PROJECT_ID", location="us-central1")
   model = aiplatform.generation.GenerativeModel("text-bison@002")
   print(model.predict("Hello world").text)
   ```
   This should succeed without a 403 if the roles and access are correct.
5. **Consider model version:** Note that `text-bison@002` is a stable version discontinued on April 9, 2025. If your project cannot access it (e.g., due to deprecation rules), switch to a currently supported model.

### Documentation References
- [Vertex AI IAM Roles – Generative AI Access Control](https://cloud.google.com/vertex-ai/docs/generative-ai/access-control): "Make prompt requests – `aiplatform.endpoints.predict`" (requires Vertex AI User/Admin).
- [Vertex AI Text Models Reference](https://cloud.google.com/vertex-ai/docs/generative-ai/learn/models): Caution about PaLM2 deprecation – new projects cannot use PaLM2 models (text-bison, etc.) after Oct 9, 2024, and all access ends Apr 9, 2025.
- [Vertex AI IAM Permissions Reference](https://cloud.google.com/vertex-ai/docs/generative-ai/access-control): `aiplatform.endpoints.predict` is needed on the endpoint resource (apply via the above roles). 