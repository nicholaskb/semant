# Vertex AI Integration Documentation

## Overview
This document describes the integration of Google Vertex AI into our multi-agent system, specifically focusing on the `VertexEmailAgent` implementation. The integration provides AI-powered email enhancement capabilities while maintaining a fallback simulation mode for development and testing.

## Architecture

### Components
1. **VertexEmailAgent**
   - Core agent responsible for email processing and enhancement
   - Integrates with Google Vertex AI for content enhancement
   - Implements fallback simulation mode when Vertex AI is unavailable

2. **Message Processing**
   - Handles incoming `AgentMessage` objects
   - Validates message content and type
   - Routes messages to appropriate handlers

3. **Knowledge Graph Integration**
   - Stores enhanced email content in the knowledge graph
   - Maintains relationships between emails and related concepts
   - Enables semantic search and retrieval

## Setup and Configuration

### Prerequisites
1. Google Cloud Project with Vertex AI API enabled
2. Service account credentials with Vertex AI access
3. Python environment with required packages:
   ```bash
   pip install google-cloud-aiplatform vertexai
   ```

### Environment Variables
```bash
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account-key.json
```

## Testing

### Test Suite Structure
The test suite (`test_vertex_integration.py`) covers:

1. **Initialization Tests**
   - Vertex AI client initialization
   - Simulation mode fallback
   - Configuration validation

2. **Email Enhancement Tests**
   - Content enhancement with Vertex AI
   - Fallback behavior in simulation mode
   - Content validation

3. **Message Processing Tests**
   - Valid message handling
   - Invalid message type handling
   - Error conditions

4. **Knowledge Graph Integration Tests**
   - Content storage
   - Relationship management
   - Query functionality

5. **Error Handling Tests**
   - Invalid email addresses
   - Empty content
   - Authentication failures

### Running Tests
```bash
# Run all tests
pytest scratch_space/test_vertex_integration.py -v

# Run specific test category
pytest scratch_space/test_vertex_integration.py -v -k "test_email_enhancement"
```

## Usage Examples

### Basic Email Enhancement
```python
from agents.domain.vertex_email_agent import VertexEmailAgent
from agents.core.base_agent import AgentMessage

async def send_enhanced_email():
    agent = VertexEmailAgent()
    await agent.initialize()
    
    message = AgentMessage(
        sender="user",
        recipient="vertex_email_agent",
        content={
            "recipient": "recipient@example.com",
            "subject": "Test Subject",
            "body": "Original content"
        },
        message_type="send_email",
        timestamp=datetime.now().timestamp()
    )
    
    response = await agent.process_message(message)
    return response
```

### Knowledge Graph Integration
```python
# Query enhanced email content
query = {
    "sparql": """
    SELECT ?email ?content
    WHERE {
        ?email dMaster:hasContent ?content .
        ?email dMaster:type "enhanced_email"
    }
    """
}
results = await agent.query_knowledge_graph(query)
```

## Troubleshooting

### Common Issues

1. **Authentication Errors**
   - Verify service account credentials
   - Check GOOGLE_APPLICATION_CREDENTIALS environment variable
   - Ensure Vertex AI API is enabled

2. **Simulation Mode**
   - Expected behavior when credentials are missing
   - No actual API calls are made
   - Content remains unchanged

3. **Message Processing Errors**
   - Validate message format
   - Check required fields
   - Verify message type

### Debugging Tips

1. Enable debug logging:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

2. Check simulation mode status:
```python
print(f"Simulation mode: {agent.simulation_mode}")
```

3. Verify message content:
```python
print(f"Message validation: {agent.validate_message(message)}")
```

## Future Improvements

1. **Enhanced Content Generation**
   - Support for multiple languages
   - Style customization
   - Template-based enhancement

2. **Knowledge Graph Features**
   - Advanced semantic search
   - Content summarization
   - Relationship inference

3. **Error Recovery**
   - Automatic retry mechanism
   - Graceful degradation
   - Enhanced error reporting

## Contributing

1. Follow the test-driven development approach
2. Add tests for new features
3. Update documentation
4. Maintain backward compatibility

## References

- [Google Vertex AI Documentation](https://cloud.google.com/vertex-ai)
- [Python Client Library](https://googleapis.dev/python/vertexai/latest/index.html)
- [Knowledge Graph Best Practices](https://cloud.google.com/knowledge-graph/docs/best-practices) 