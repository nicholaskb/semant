# Working Guide for Data Challenge Assistant

## Core Principles

### 1. ALWAYS LOOK FOR CODE BEFORE WRITING
- First, list directory contents to understand the codebase structure
- Search for existing implementations using semantic search
- Use grep search for specific patterns or implementations
- Compare existing code with proposed changes
- Document findings in scratch_space before making changes
- Check for similar patterns in other work packages
- Review related test files for implementation details
- Look for existing error handling patterns
- Check for security implementations
- Review performance optimizations

### 2. ALWAYS UPDATE CODE BEFORE WRITING
- Take an iterative approach to code changes
- Document each iteration in scratch_space
- Use version control patterns in file naming (e.g., _updates.md)
- Maintain backward compatibility
- Follow existing code patterns and conventions
- Create backup of files before major changes
- Document breaking changes
- Update related test files
- Update documentation
- Check for impact on other components

### 3. ALWAYS USE SCRATCH_SPACE
- Create analysis files before implementation
- Log all changes and decisions
- Maintain clear documentation of progress
- Use consistent file naming patterns
- Keep track of dependencies and relationships
- Document design decisions
- Track performance metrics
- Log error patterns
- Document security considerations
- Maintain change history

### 4. ALWAYS UPDATE ONTOLOGY
- Add new triples to the knowledge graph
- Document ontology changes
- Maintain semantic consistency
- Follow OWL best practices
- Validate changes with reasoner
- Update related schemas
- Document relationships
- Check for conflicts
- Maintain version history
- Update documentation

## Critical Rules

### 1. Code Review Rules
- Never commit without self-review
- Check for security vulnerabilities
- Verify error handling
- Test edge cases
- Document assumptions
- Check performance impact
- Verify backward compatibility
- Review test coverage
- Check documentation
- Validate against requirements

### 2. Testing Rules
- Write tests before implementation
- Cover edge cases
- Test error conditions
- Verify performance
- Check security
- Test integration points
- Validate data consistency
- Test recovery scenarios
- Verify monitoring
- Document test cases

### 3. Security Rules
- Never hardcode credentials
- Validate all inputs
- Sanitize all outputs
- Use secure communication
- Implement proper authentication
- Follow least privilege
- Log security events
- Monitor for breaches
- Regular security audits
- Update security documentation

### 4. Performance Rules
- Monitor resource usage
- Profile critical paths
- Cache appropriately
- Optimize queries
- Handle concurrency
- Manage memory
- Monitor latency
- Track throughput
- Document bottlenecks
- Plan for scale

### 5. Documentation Rules
- Keep README updated
- Document API changes
- Update changelog
- Maintain architecture docs
- Document security
- Update performance metrics
- Keep test docs current
- Document dependencies
- Update deployment guides
- Maintain troubleshooting guides

### 6. Integration Rules
- Define clear interfaces
- Document contracts
- Handle versioning
- Manage dependencies
- Test integration points
- Monitor integration health
- Document integration patterns
- Handle failures gracefully
- Maintain backward compatibility
- Update integration docs

### 7. Monitoring Rules
- Set up proper logging
- Define metrics
- Set up alerts
- Monitor performance
- Track errors
- Monitor security
- Track resource usage
- Monitor integration health
- Set up dashboards
- Document monitoring

### 8. Deployment Rules
- Use version control
- Document deployment steps
- Test deployment
- Monitor deployment
- Handle rollbacks
- Update documentation
- Verify security
- Check performance
- Validate configuration
- Document issues

## Working Process

### 1. Initial Analysis
```bash
# Always start with:
list_dir <directory>
codebase_search <query>
grep_search <pattern>
```

### 2. Documentation
- Create analysis file in scratch_space
- Document current state
- List requirements
- Plan implementation
- Define success criteria

### 3. Implementation
- Follow existing patterns
- Make incremental changes
- Update documentation
- Add tests
- Update ontology

### 4. Validation
- Run tests
- Check ontology consistency
- Verify performance
- Document results
- Update scratch_space

## Best Practices

### 1. Code Organization
- Follow existing directory structure
- Use consistent naming conventions
- Maintain clear file organization
- Document dependencies
- Keep related files together

### 2. Documentation
- Update README files
- Document API changes
- Maintain changelog
- Keep scratch_space organized
- Document decisions

### 3. Testing
- Write unit tests
- Add integration tests
- Document test cases
- Maintain test coverage
- Update test documentation

### 4. Ontology Management
- Add new classes and properties
- Document relationships
- Maintain consistency
- Follow OWL patterns
- Validate changes

## Communication Patterns

### 1. Progress Updates
- Regular status updates
- Clear documentation
- Progress tracking
- Issue reporting
- Solution proposals

### 2. Decision Making
- Document alternatives
- Explain choices
- Consider impact
- Maintain consistency
- Follow patterns

### 3. Problem Solving
- Analyze issues
- Propose solutions
- Document decisions
- Implement fixes
- Verify results

## Data Challenge Specific

### 1. Self-Assembly Requirements
- Focus on modularity
- Maintain clear boundaries
- Support hot-swapping
- Enable dynamic updates
- Ensure consistency

### 2. Knowledge Graph Integration
- Add new triples
- Maintain relationships
- Update schemas
- Validate changes
- Document updates

### 3. Agent Management
- Support dynamic creation
- Enable role delegation
- Maintain state
- Handle failures
- Monitor performance

## Success Metrics

### 1. Code Quality
- Test coverage
- Documentation
- Performance
- Maintainability
- Consistency

### 2. System Performance
- Response times
- Resource usage
- Scalability
- Reliability
- Security

### 3. Knowledge Graph
- Completeness
- Consistency
- Performance
- Usability
- Maintainability

## Tools and Commands

### 1. Directory Operations
```bash
list_dir <path>
file_search <pattern>
```

### 2. Code Search
```bash
codebase_search <query>
grep_search <pattern>
```

### 3. File Operations
```bash
read_file <file>
edit_file <file>
delete_file <file>
```

### 4. Terminal Commands
```bash
run_terminal_cmd <command>
```

## Remember
- Always check existing code first
- Document everything in scratch_space
- Follow iterative development
- Maintain ontology consistency
- Keep communication clear
- Focus on modularity
- Support self-assembly
- Enable dynamic updates
- Ensure system reliability
- Maintain security
- Never skip testing
- Always validate changes
- Keep security in mind
- Monitor performance
- Document everything
- Follow patterns
- Check dependencies
- Verify integration
- Test thoroughly
- Update documentation 