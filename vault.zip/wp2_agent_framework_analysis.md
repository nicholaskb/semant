# Work Package 2: Agent Framework & Data Ingestion Analysis

## Data Challenge Requirements

### Core Requirements
1. Agent Framework
   - Must handle concurrent agent operations
   - Must maintain thread safety
   - Must support dynamic agent creation
   - Must implement proper error handling

2. Data Ingestion
   - Must support multiple data sources
   - Must handle data validation
   - Must implement proper logging
   - Must maintain data consistency

### Performance Requirements
1. Response Time
   - Average response time < 200ms
   - Maximum response time < 1s
   - Query performance < 100ms

2. Resource Usage
   - CPU utilization < 80%
   - Memory usage < 70%
   - Disk I/O < 60%

3. Scalability
   - Support 1000+ concurrent agents
   - Handle 10000+ triples/second
   - Process 1000+ events/second

### Security Requirements
1. Authentication
   - Proper agent authentication
   - Secure graph access
   - Role-based permissions

2. Data Protection
   - Encrypted data storage
   - Secure communication
   - Access control

## Current State Assessment

### Agent Framework Requirements
1. Base Agent Class ✓
   - Graph access
   - Agent URI management
   - Run method interface
   - Thread safety
   - Error handling

2. Agent Types ✓
   - SensorAgent
   - DataProcessorAgent
   - MaintenanceAgent
   - ReportingAgent
   - OrchestratorAgent

3. Graph Interaction ✓
   - Triple reading/writing
   - SPARQL query support
   - State management
   - Concurrent access handling

## Implementation Plan

### 1. Base Agent Framework
```python
from abc import ABC, abstractmethod
from rdflib import Graph, Namespace, URIRef, Literal
import logging
import threading
from datetime import datetime
import time
import psutil

class BaseAgent(ABC):
    """Base class for all agents in the system."""
    
    def __init__(self, graph: Graph, agent_uri: URIRef):
        self.graph = graph
        self.agent_uri = agent_uri
        self.logger = logging.getLogger(self.__class__.__name__)
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.register_agent()
    
    def register_agent(self):
        """Register the agent in the knowledge graph."""
        with self.lock:
            self.graph.add((self.agent_uri, RDF.type, self.get_agent_type()))
            self.graph.add((self.agent_uri, self.ex.hasStatus, Literal("Idle")))
            self.graph.add((self.agent_uri, self.ex.hasVersion, Literal("1.0")))
            self.graph.add((self.agent_uri, self.ex.lastModified, Literal(datetime.now())))
            self.graph.add((self.agent_uri, self.ex.hasRole, self.get_agent_role()))
    
    @abstractmethod
    def get_agent_type(self) -> URIRef:
        """Return the agent's type URI."""
        pass
    
    @abstractmethod
    def get_agent_role(self) -> URIRef:
        """Return the agent's role URI."""
        pass
    
    @abstractmethod
    def run(self):
        """Main execution loop for the agent."""
        pass
    
    def update_status(self, status: str):
        """Update agent status in the graph."""
        with self.lock:
            self.graph.set((self.agent_uri, self.ex.hasStatus, Literal(status)))
            self.graph.set((self.agent_uri, self.ex.lastModified, Literal(datetime.now())))
    
    def monitor_resources(self):
        """Monitor agent resource usage."""
        process = psutil.Process()
        cpu_percent = process.cpu_percent()
        memory_percent = process.memory_percent()
        
        with self.lock:
            self.graph.add((self.agent_uri, self.ex.cpuUsage, Literal(cpu_percent)))
            self.graph.add((self.agent_uri, self.ex.memoryUsage, Literal(memory_percent)))
```

### 2. Specialized Agents

#### SensorAgent
```python
class SensorAgent(BaseAgent):
    """Agent responsible for reading sensor data."""
    
    def __init__(self, graph: Graph, agent_uri: URIRef, sensor_uri: URIRef):
        super().__init__(graph, agent_uri)
        self.sensor_uri = sensor_uri
        self.graph.add((self.agent_uri, self.ex.monitors, sensor_uri))
    
    def get_agent_type(self) -> URIRef:
        return self.ex.SensorAgent
    
    def get_agent_role(self) -> URIRef:
        return self.ex.SensorReader
    
    def run(self):
        """Read sensor data and update the graph."""
        while not self.stop_event.is_set():
            try:
                start_time = time.perf_counter()
                self.update_status("Active")
                reading = self.read_sensor()
                self.update_sensor_reading(reading)
                self.monitor_resources()
                self.update_status("Idle")
                
                elapsed = (time.perf_counter() - start_time) * 1000
                if elapsed > 200:
                    self.logger.warning(f"Response time {elapsed:.1f}ms exceeds 200ms")
                
                time.sleep(0.1)  # Prevent CPU overload
            except Exception as e:
                self.logger.error(f"Error in sensor reading: {e}")
                self.update_status("Error")
                self.graph.add((self.agent_uri, self.ex.lastError, Literal(str(e))))
```

#### DataProcessorAgent
```python
class DataProcessorAgent(BaseAgent):
    """Agent responsible for processing sensor data."""
    
    def get_agent_type(self) -> URIRef:
        return self.ex.DataProcessorAgent
    
    def run(self):
        """Process sensor data and detect anomalies."""
        try:
            self.update_status("Active")
            self.process_sensor_data()
            self.update_status("Idle")
        except Exception as e:
            self.logger.error(f"Error in data processing: {e}")
            self.update_status("Error")
    
    def process_sensor_data(self):
        """Process sensor readings and detect anomalies."""
        query = """
        SELECT ?sensor ?reading WHERE {
            ?sensor ex:latestReading ?reading .
        }
        """
        for sensor, reading in self.graph.query(query):
            if float(reading) > self.threshold:
                self.graph.add((sensor, self.ex.anomalyDetected, Literal(True)))
```

### 3. Agent Factory
```python
class AgentFactory:
    """Factory for creating and managing agents."""
    
    def __init__(self, graph: Graph):
        self.graph = graph
        self.agent_types = {
            "SensorAgent": SensorAgent,
            "DataProcessorAgent": DataProcessorAgent,
            "MaintenanceAgent": MaintenanceAgent,
            "ReportingAgent": ReportingAgent,
            "OrchestratorAgent": OrchestratorAgent
        }
        self.active_agents = {}
        self.lock = threading.Lock()
    
    def create_agent(self, agent_type: str, **kwargs) -> BaseAgent:
        """Create a new agent instance."""
        with self.lock:
            if agent_type not in self.agent_types:
                raise ValueError(f"Unknown agent type: {agent_type}")
            
            agent_class = self.agent_types[agent_type]
            agent_uri = self.generate_agent_uri(agent_type)
            agent = agent_class(self.graph, agent_uri, **kwargs)
            
            # Start agent in a new thread
            thread = threading.Thread(target=agent.run, name=f"{agent_type}-{agent_uri}")
            thread.daemon = True
            thread.start()
            
            self.active_agents[agent_uri] = thread
            return agent
    
    def stop_agent(self, agent_uri: URIRef):
        """Stop an agent gracefully."""
        with self.lock:
            if agent_uri in self.active_agents:
                thread = self.active_agents[agent_uri]
                thread.join(timeout=5)
                del self.active_agents[agent_uri]
```

## Testing Strategy

### 1. Unit Tests
```python
def test_sensor_agent():
    """Test SensorAgent functionality."""
    graph = Graph()
    agent_uri = ex.Agent1
    sensor_uri = ex.Sensor1
    
    agent = SensorAgent(graph, agent_uri, sensor_uri)
    agent.run()
    
    # Verify agent registration
    assert (agent_uri, RDF.type, ex.SensorAgent) in graph
    assert (agent_uri, ex.hasRole, ex.SensorReader) in graph
    
    # Verify sensor reading update
    readings = list(graph.objects(sensor_uri, ex.latestReading))
    assert len(readings) > 0
    
    # Verify agent status
    status = graph.value(agent_uri, ex.hasStatus)
    assert status == Literal("Idle")
    
    # Verify resource monitoring
    cpu_usage = graph.value(agent_uri, ex.cpuUsage)
    assert cpu_usage is not None
    assert float(cpu_usage) < 80.0
```

### 2. Integration Tests
```python
def test_agent_interaction():
    """Test interaction between agents via the graph."""
    graph = Graph()
    factory = AgentFactory(graph)
    
    # Create agents
    sensor_agent = factory.create_agent("SensorAgent", sensor_uri=ex.Sensor1)
    processor_agent = factory.create_agent("DataProcessorAgent")
    
    # Wait for processing
    time.sleep(1)
    
    # Verify data flow
    anomalies = list(graph.subjects(ex.anomalyDetected, Literal(True)))
    assert len(anomalies) > 0
    
    # Verify performance
    for agent_uri in [sensor_agent.agent_uri, processor_agent.agent_uri]:
        cpu_usage = float(graph.value(agent_uri, ex.cpuUsage))
        memory_usage = float(graph.value(agent_uri, ex.memoryUsage))
        assert cpu_usage < 80.0
        assert memory_usage < 70.0
```

## Next Steps

1. Implement remaining agent types
2. Add configuration management
3. Implement error handling
4. Add monitoring capabilities
5. Create deployment scripts
6. Add security measures
7. Implement performance monitoring
8. Add resource management

## Success Criteria

1. Agent Framework
   - All agent types implemented
   - Proper graph interaction
   - Error handling
   - Status tracking
   - Thread safety
   - Resource monitoring

2. Data Ingestion
   - Sensor data reading
   - Data processing
   - Anomaly detection
   - Graph updates
   - Performance metrics
   - Security measures

3. Performance
   - Fast agent creation
   - Efficient graph queries
   - Low latency updates
   - Resource management
   - Scalability
   - Reliability

## Extensibility Hooks

1. New Agent Types
   - Easy to add new agents
   - Configurable behavior
   - Standard interfaces
   - Role management

2. Data Sources
   - Pluggable sensor interfaces
   - External data integration
   - Custom processors
   - Data validation

3. Monitoring
   - Performance metrics
   - Health checks
   - Status reporting
   - Resource tracking 