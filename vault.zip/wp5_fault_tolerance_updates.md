# Work Package 5: Fault Tolerance and Monitoring Updates

## Data Challenge Evaluation Requirements

### Core Requirements
1. Fault Detection
   - Must detect agent failures within 5 seconds
   - Must identify stuck tasks within 1 minute
   - Must validate data consistency in real-time
   - Must track error patterns and trends
   - Must support custom failure detectors
   - Must implement comprehensive logging

2. Recovery Mechanisms
   - Must recover from agent failures within 10 seconds
   - Must reassign tasks within 5 seconds
   - Must restore system state within 30 seconds
   - Must maintain data consistency during recovery
   - Must support multiple recovery strategies
   - Must implement rollback capabilities

3. Monitoring System
   - Must track system health metrics in real-time
   - Must monitor performance with <1% overhead
   - Must manage alerts with priority levels
   - Must provide system state visualization
   - Must support custom metrics
   - Must implement trend analysis

### Performance Requirements
1. Response Time
   - Fault detection < 5 seconds
   - Recovery initiation < 10 seconds
   - Task reassignment < 5 seconds
   - Alert generation < 1 second

2. Resource Usage
   - CPU overhead < 5%
   - Memory overhead < 10%
   - Disk I/O < 5%
   - Network I/O < 5%

3. Scalability
   - Support 1000+ concurrent agents
   - Handle 10000+ tasks/minute
   - Process 1000+ alerts/second
   - Monitor 100+ metrics

### Security Requirements
1. Authentication
   - Agent authentication
   - Task validation
   - Alert verification
   - Recovery authorization

2. Data Protection
   - Encrypted monitoring data
   - Secure alert transmission
   - Protected recovery actions
   - Safe state management

## Implementation Updates

### 1. Enhanced WatchdogAgent
```python
class WatchdogAgent(BaseAgent):
    """Enhanced watchdog with improved monitoring and recovery."""
    
    def __init__(self, graph: Graph, agent_uri: URIRef):
        super().__init__(graph, agent_uri)
        self.timeout_threshold = 60  # 1 minute
        self.failure_threshold = 5  # 5 seconds
        self.logger = logging.getLogger(self.__class__.__name__)
        self.metrics = MonitoringMetrics()
    
    def monitor_system(self):
        """Enhanced system monitoring with metrics and security."""
        try:
            start_time = time.perf_counter()
            
            # Check for stuck tasks
            self.check_stuck_tasks()
            
            # Check for failed agents
            self.check_failed_agents()
            
            # Verify data consistency
            self.verify_data_consistency()
            
            # Update metrics
            elapsed = (time.perf_counter() - start_time) * 1000
            self.metrics.record_monitoring_time(elapsed)
            
        except Exception as e:
            self.logger.error(f"Error monitoring system: {e}")
            self.metrics.record_error(e)
    
    def check_stuck_tasks(self):
        """Check for tasks stuck in progress."""
        stuck_tasks = self.graph.query("""
            SELECT ?t WHERE {
                ?t ex:status ex:InProgress .
                ?t ex:lastUpdated ?time .
                FILTER(now()-?time > ?threshold)
            }
        """, initBindings={'threshold': self.timeout_threshold})
        
        for task in stuck_tasks:
            self.handle_stuck_task(task[0])
    
    def handle_stuck_task(self, task: URIRef):
        """Handle a stuck task with recovery."""
        try:
            # Mark task as failed
            self.graph.add((task, ex:status, ex:Failed))
            
            # Create alert
            alert = self.create_alert("Task timeout", "High")
            
            # Reassign task
            self.reassign_task(task)
            
            # Record metrics
            self.metrics.record_task_recovery()
            
        except Exception as e:
            self.logger.error(f"Error handling stuck task: {e}")
            self.metrics.record_error(e)
```

### 2. Enhanced HealthMonitor
```python
class HealthMonitor(BaseAgent):
    """Enhanced health monitor with improved tracking and recovery."""
    
    def __init__(self, graph: Graph, agent_uri: URIRef):
        super().__init__(graph, agent_uri)
        self.health_check_interval = 5  # 5 seconds
        self.logger = logging.getLogger(self.__class__.__name__)
        self.metrics = HealthMetrics()
    
    def monitor_health(self):
        """Enhanced health monitoring with metrics and security."""
        try:
            start_time = time.perf_counter()
            
            # Check agent health
            self.check_agent_health()
            
            # Check system resources
            self.check_system_resources()
            
            # Check data consistency
            self.check_data_consistency()
            
            # Update metrics
            elapsed = (time.perf_counter() - start_time) * 1000
            self.metrics.record_health_check_time(elapsed)
            
        except Exception as e:
            self.logger.error(f"Error monitoring health: {e}")
            self.metrics.record_error(e)
    
    def check_agent_health(self):
        """Check health of all agents."""
        agents = self.graph.query("""
            SELECT ?a WHERE {
                ?a rdf:type ex:Agent .
                ?a ex:status ?status .
                FILTER(?status = ex:Failed)
            }
        """)
        
        for agent in agents:
            self.handle_failed_agent(agent[0])
    
    def handle_failed_agent(self, agent: URIRef):
        """Handle a failed agent with recovery."""
        try:
            # Mark agent for restart
            self.graph.add((agent, ex:needsRestart, Literal(True)))
            
            # Create alert
            self.create_alert("Agent failure", "High")
            
            # Reassign tasks
            self.reassign_agent_tasks(agent)
            
            # Record metrics
            self.metrics.record_agent_recovery()
            
        except Exception as e:
            self.logger.error(f"Error handling failed agent: {e}")
            self.metrics.record_error(e)
```

### 3. Enhanced DataConsistencyChecker
```python
class DataConsistencyChecker(BaseAgent):
    """Enhanced data consistency checker with improved validation."""
    
    def __init__(self, graph: Graph, agent_uri: URIRef):
        super().__init__(graph, agent_uri)
        self.consistency_check_interval = 10  # 10 seconds
        self.logger = logging.getLogger(self.__class__.__name__)
        self.metrics = ConsistencyMetrics()
    
    def check_consistency(self):
        """Enhanced consistency checking with metrics and security."""
        try:
            start_time = time.perf_counter()
            
            # Check task consistency
            self.check_task_consistency()
            
            # Check agent consistency
            self.check_agent_consistency()
            
            # Check data consistency
            self.check_data_consistency()
            
            # Update metrics
            elapsed = (time.perf_counter() - start_time) * 1000
            self.metrics.record_consistency_check_time(elapsed)
            
        except Exception as e:
            self.logger.error(f"Error checking consistency: {e}")
            self.metrics.record_error(e)
    
    def check_task_consistency(self):
        """Check consistency of task data."""
        inconsistencies = self.graph.query("""
            SELECT ?s ?p WHERE {
                ?s rdf:type ex:Task .
                ?s ex:status ex:InProgress .
                OPTIONAL { ?s ex:assignedTo ?agent }
                FILTER(!BOUND(?agent))
            }
        """)
        
        for s, p in inconsistencies:
            self.handle_inconsistency(s, p)
    
    def handle_inconsistency(self, subject: URIRef, predicate: URIRef):
        """Handle data inconsistency with recovery."""
        try:
            # Create alert
            self.create_alert("Data inconsistency", "High")
            
            # Attempt recovery
            self.recover_inconsistency(subject, predicate)
            
            # Record metrics
            self.metrics.record_inconsistency_recovery()
            
        except Exception as e:
            self.logger.error(f"Error handling inconsistency: {e}")
            self.metrics.record_error(e)
```

## Testing Strategy Updates

### 1. Enhanced Unit Tests
```python
def test_fault_detection():
    """Test fault detection with metrics and timing."""
    graph = Graph()
    watchdog = WatchdogAgent(graph, ex.Watchdog1)
    
    # Create test scenario
    create_test_scenario(graph)
    
    # Run monitoring
    start_time = time.perf_counter()
    watchdog.monitor_system()
    elapsed = (time.perf_counter() - start_time) * 1000
    
    # Verify detection
    assert elapsed < 5000, f"Detection time {elapsed}ms exceeds 5s"
    assert watchdog.metrics.get_error_count() == 0
    assert watchdog.metrics.get_success_rate() == 1.0
```

### 2. Enhanced Integration Tests
```python
def test_system_recovery():
    """Test system recovery from multiple failures."""
    graph = Graph()
    monitor = HealthMonitor(graph, ex.Monitor1)
    
    # Create failure scenario
    create_failure_scenario(graph)
    
    # Run recovery
    monitor.monitor_health()
    
    # Verify recovery
    assert graph.value(ex.Task1, ex.status) == ex.Done
    assert graph.value(ex.Agent1, ex.status) == ex.Active
```

## Next Steps

1. Implement enhanced watchdog agent
2. Add health monitoring
3. Implement consistency checking
4. Create test framework
5. Add monitoring dashboard
6. Implement security
7. Add documentation

## Success Criteria

1. Fault Management
   - Successful fault detection
   - Proper recovery
   - Data consistency
   - Error handling

2. Performance
   - Meet response time targets
   - Stay within resource limits
   - Handle required load
   - Maintain stability

3. Security
   - Proper authentication
   - Data protection
   - Alert security
   - Recovery safety

## Extensibility Hooks

1. Fault Detection
   - Custom detectors
   - Pattern recognition
   - Trend analysis
   - Alert customization

2. Recovery Strategies
   - Custom recovery
   - State management
   - Rollback support
   - Validation rules

3. Monitoring
   - Custom metrics
   - Visualization
   - Alert handling
   - Performance tracking 